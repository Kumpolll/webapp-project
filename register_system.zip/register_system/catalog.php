<?php
session_start();
include('server.php'); // Include your database connection code here
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Catalog</title>
    <link rel="stylesheet" href="style.css"> <!-- Include your CSS file here -->

</head>
<body>
    <div class="header">
        <h2>Product Catalog</h2>
    </div>

    <?php
    // Fetch products from the database
    $query = "SELECT * FROM products";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo '<div class="product">';
            echo '<img src="' . $row['image'] . '" alt="' . $row['product_name'] . '" width="400" height="auto">';
            echo '<h3>' . $row['product_name'] . '</h3>';
            echo '<p>Price: $' . $row['price'] . '</p>';
            echo '<p>Description: ' . $row['description'] . '</p>';
            echo '<p><br><br></p>';
            echo '</div>';

        }
    } else {
        echo '<p>No products available.</p>';
    }
    ?>

    <p><a href="index.php">Back to Home</a></p>
</body>
</html>
